// script.js
$(document).ready(function() {
    function performSearch() {
        let query = $('#search').val();
        
        if (query.length > 2) {
            $.ajax({
                url: 'search.php', // Cambia questo URL con l'URL del tuo endpoint di ricerca
                type: 'GET',
                data: { q: query },
                success: function(data) {
                    $('#results').html(data);
                }
            });
        } else {
            $('#results').empty();
        }
    }

    $('#search').on('input', function() {
        performSearch();
    });

    $('#search-btn').on('click', function() {
        performSearch();
    });
});
